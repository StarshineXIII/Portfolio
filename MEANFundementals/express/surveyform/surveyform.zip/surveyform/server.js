var express = require('express');

var app = express();
var bodyParser = require('body-parser');
var session = require('express-session');

app.use(bodyParser.urlencoded({extended: true}));

app.use(session({secret: 'surveyform'})); 
app.set('views', __dirname + "/views");
app.set('view engine', 'ejs');

// gets the root route
app.get("/", function(req, res){
	res.render("index");
})

//posts on the result page, req.session.results has to be defined here.
app.post("/result", function(req, res){
	req.session.results = req.body; //body-parser?
	res.redirect("/result")
})

//actually ties the results in from the survey form to the results page with the {results:results}, dont forget to define results
app.get("/result", function(req, res){
	results = req.session.results;
	res.render('result', {results: results});
})

app.listen(8000, function(){
	console.log("Listening on port 8000");
})